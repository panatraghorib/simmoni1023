<template>
  <footer class="p-6">
    <slot />
  </footer>
</template>
