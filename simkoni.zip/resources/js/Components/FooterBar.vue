<script setup>
import { containerMaxW } from "@/config.js";
import BaseLevel from "@/components/BaseLevel.vue";
import AtraLogo from "@/components/AtraLogo.vue";

const year = new Date().getFullYear();
</script>

<template>
    <footer class="py-2 px-6" :class="containerMaxW">
        <BaseLevel>
            <div class="text-center md:text-left">
                <b>&copy;{{ year }}, <a href="#" target="_blank">tes</a>.</b>
                <slot />
            </div>
            <div class="md:py-2">
                <a href="#">
                    <AtraLogo class="w-auto h-8 md:h-6" />
                </a>
            </div>
        </BaseLevel>
    </footer>
</template>
